<?php
/**
 * ملف تشغيل البوت (bot.py) على استضافة تدعم PHP فقط.
 *
 * الفكرة: هذا الملف لا "يستبدل" البوت (البوت لا يزال مكتوباً بلغة Python
 * ويحتاج ملفاته الأصلية: bot.py + adder.db + المكتبات المطلوبة).
 * دور هذا الملف فقط هو تشغيل بوت البايثون كعملية خلفية على السيرفر،
 * والتأكد أنه لا يزال يعمل، وإعادة تشغيله تلقائياً إذا توقف.
 *
 * طريقة الاستخدام:
 * 1) ارفع هذا الملف + bot.py + adder.db + pyproject.toml (أو requirements.txt)
 *    إلى نفس المجلد على السيرفر.
 * 2) تأكد أن السيرفر يدعم تنفيذ أوامر النظام (shell_exec / exec) — بعض
 *    الاستضافات المشتركة الرخيصة تمنع هذه الدالة لأسباب أمنية.
 * 3) ثبّت بايثون والمكتبات المطلوبة على السيرفر (عادة عبر SSH أو لوحة التحكم):
 *      pip install aiogram telethon
 * 4) أنشئ Cron Job من لوحة تحكم الاستضافة يستدعي هذا الملف كل 5 دقائق:
 *      wget -q -O /dev/null "https://yourdomain.com/bot_runner.php"
 *    أو عبر أمر مباشر:
 *      php /home/username/public_html/bot_runner.php
 *
 * ملاحظة مهمة: عدّل المسارات أدناه ($botDir, $pythonBin) لتطابق مسارات
 * استضافتك الفعلية.
 */

// عدّل هذا المسار ليطابق مكان رفع ملفات البوت على السيرفر
$botDir = __DIR__;

// أمر تشغيل بايثون - قد يكون python3 أو مسار كامل مثل /usr/bin/python3
$pythonBin = "python3";

$botScript = $botDir . "/bot.py";
$pidFile   = $botDir . "/bot.pid";
$logFile   = $botDir . "/bot_output.log";

function isProcessRunning(int $pid): bool
{
    if ($pid <= 0) {
        return false;
    }
    // على أنظمة لينكس: التحقق من وجود مجلد العملية في /proc
    return file_exists("/proc/{$pid}");
}

$isRunning = false;

if (file_exists($pidFile)) {
    $pid = (int) trim(file_get_contents($pidFile));
    $isRunning = isProcessRunning($pid);
}

if ($isRunning) {
    echo "البوت يعمل بالفعل (PID: {$pid})\n";
    exit;
}

if (!function_exists('shell_exec')) {
    echo "خطأ: دالة shell_exec غير مفعّلة على هذه الاستضافة، لا يمكن تشغيل البوت بهذه الطريقة.\n";
    echo "يُرجى التواصل مع الدعم الفني للاستضافة لتفعيلها، أو استخدام استضافة تدعم تشغيل عمليات بايثون مباشرة (مثل VPS).\n";
    exit;
}

// تشغيل البوت كعملية خلفية وحفظ رقم العملية (PID)
$command = "cd " . escapeshellarg($botDir) . " && nohup " . escapeshellarg($pythonBin) . " "
    . escapeshellarg($botScript) . " >> " . escapeshellarg($logFile) . " 2>&1 & echo $!";

$newPid = trim(shell_exec($command));

if ($newPid && is_numeric($newPid)) {
    file_put_contents($pidFile, $newPid);
    echo "تم تشغيل البوت بنجاح (PID: {$newPid})\n";
} else {
    echo "فشل تشغيل البوت. تحقق من تثبيت بايثون والمكتبات، ومن صلاحيات shell_exec على السيرفر.\n";
}
