<?php
/**
 * بوت تليجرام بسيط يعمل عبر Telegram Bot API (وليس Telethon/MTProto).
 *
 * هذا الملف صالح للاستضافة على خدمات "استضافة بوتات PHP" التي تعمل عبر
 * Webhook. لكن يجب معرفة القيد التالي بوضوح:
 *
 *   لا يمكن لهذا الملف (ولا لأي ملف PHP في هذا النوع من الاستضافة) تنفيذ
 *   وظيفة "إضافة الأعضاء" الموجودة في bot.py الأصلي، لأن تلك الوظيفة تحتاج
 *   تسجيل دخول بحساب تليجرام حقيقي عبر بروتوكول MTProto (مكتبة Telethon)
 *   واتصالاً دائماً مفتوحاً - وهذا غير مدعوم في استضافات البوتات القائمة
 *   على Webhook مثل هذه الخدمة.
 *
 * ما يفعله هذا الملف فعلياً: بوت رد آلي بسيط (يستقبل الرسائل ويرد عليها)
 * فقط، ليصلح للاختبار والتأكد من نجاح الاستضافة.
 *
 * --- الإعداد ---
 * 1) استبدل القيمة أدناه بتوكن بوتك (من BotFather):
 */

define('BOT_TOKEN', 'ضع_توكن_البوت_هنا');
define('API_URL', 'https://api.telegram.org/bot' . BOT_TOKEN . '/');

function apiRequest(string $method, array $params = [])
{
    $url = API_URL . $method;

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);

    $response = curl_exec($ch);
    curl_close($ch);

    return json_decode($response, true);
}

function sendMessage(int $chatId, string $text, array $extra = [])
{
    return apiRequest('sendMessage', array_merge([
        'chat_id' => $chatId,
        'text' => $text,
        'parse_mode' => 'HTML',
    ], $extra));
}

// استقبال التحديث القادم من تليجرام عبر Webhook
$rawInput = file_get_contents('php://input');
$update = json_decode($rawInput, true);

if (!$update || !isset($update['message'])) {
    http_response_code(200);
    exit;
}

$message = $update['message'];
$chatId = $message['chat']['id'] ?? null;
$text = trim($message['text'] ?? '');

if ($chatId === null) {
    http_response_code(200);
    exit;
}

switch (true) {
    case $text === '/start':
        sendMessage($chatId, "أهلاً بك! 👋\nالبوت يعمل بنجاح على استضافة PHP.");
        break;

    case $text === '/help':
        sendMessage($chatId, "الأوامر المتاحة:\n/start - بدء البوت\n/help - عرض المساعدة");
        break;

    case $text !== '':
        sendMessage($chatId, "استلمت رسالتك: " . htmlspecialchars($text));
        break;
}

http_response_code(200);
