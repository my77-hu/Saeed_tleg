import { useState, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  Activity,
  Check,
  CheckCircle2,
  CloudCog,
  Copy,
  RefreshCw,
  ShieldCheck,
} from 'lucide-react';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

function Home() {
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastChecked, setLastChecked] = useState('الآن');
  const [isCopied, setIsCopied] = useState(false);

  const refreshStatus = () => {
    setIsRefreshing(true);
    window.setTimeout(() => {
      setLastChecked(
        new Intl.DateTimeFormat('ar-SA', {
          hour: '2-digit',
          minute: '2-digit',
        }).format(new Date()),
      );
      setIsRefreshing(false);
    }, 650);
  };

  const copyHandle = async () => {
    try {
      await navigator.clipboard?.writeText('@membership_guard_bot');
      setIsCopied(true);
      window.setTimeout(() => setIsCopied(false), 1800);
    } catch {
      setIsCopied(false);
    }
  };

  const scrollToDeployment = () => {
    document.getElementById('deployment-guide')?.scrollIntoView({
      behavior: 'smooth',
      block: 'center',
    });
  };

  return (
    <div className="app-shell" dir="rtl">
      <div className="page-frame">
        <header className="topbar animate-in" data-testid="header-control-room">
          <div className="brand-lockup" data-testid="brand-telegram-host">
            <span className="brand-mark" aria-hidden="true" />
            <div>
              <div className="brand-name">مركز الاستضافة</div>
              <div className="brand-caption">مراقبة بوت العضوية</div>
            </div>
          </div>
          <div className="topbar-meta">
            <span>المنطقة: أوروبا الغربية</span>
            <span className="live-chip" data-testid="status-live-chip">
              <span className="live-dot" aria-hidden="true" />
              الخدمة تعمل
            </span>
          </div>
        </header>

        <main>
          <section className="hero" aria-labelledby="page-title">
            <div className="animate-in delay-1">
              <p className="eyebrow">
                <span className="eyebrow-line" aria-hidden="true" />
                لوحة التشغيل
              </p>
              <h1 id="page-title">
                كل شيء تحت
                <br />
                <em>المراقبة.</em>
              </h1>
              <p className="hero-copy">
                حالة بوت إدارة العضوية في لمحة واحدة. نراقب الاتصال بتيليجرام
                باستمرار حتى تعرف أن قواعد مجموعتك تعمل عندما تحتاجها.
              </p>
            </div>

            <aside className="hero-side animate-in delay-2" aria-label="حالة الخدمة الحالية">
              <p className="hero-side-label">ملخص الخدمة / 01</p>
              <div className="service-line">
                <div className="service-name">
                  <span className="service-icon" aria-hidden="true">
                    <Activity size={18} strokeWidth={1.8} />
                  </span>
                  بوابة تيليجرام
                </div>
                <span className="service-status">متصل</span>
              </div>
              <div className="service-rule" />
              <div className="service-foot">
                <span>آخر فحص</span>
                <span dir="ltr" data-testid="text-last-checked">{lastChecked}</span>
              </div>
            </aside>
          </section>

          <section className="animate-in delay-2" aria-labelledby="metrics-title">
            <div className="section-heading">
              <div>
                <h2 id="metrics-title">نبض الخدمة</h2>
                <p>بيانات التشغيل الحالية</p>
              </div>
              <button
                className="refresh-button"
                type="button"
                onClick={refreshStatus}
                aria-busy={isRefreshing}
                data-testid="button-refresh-status"
              >
                <RefreshCw size={14} strokeWidth={2} />
                {isRefreshing ? 'جارٍ الفحص' : 'تحديث الحالة'}
              </button>
            </div>

            <div className="metrics">
              <article className="metric-card featured" data-testid="metric-uptime">
                <span className="metric-label">الاستمرارية هذا الشهر</span>
                <div className="metric-value">99.97%</div>
                <div className="metric-foot">آخر انقطاع: لا يوجد</div>
              </article>
              <article className="metric-card" data-testid="metric-latency">
                <span className="metric-label">زمن الاستجابة</span>
                <div className="metric-value">184ms</div>
                <div className="metric-foot status-row">
                  <CheckCircle2 size={13} />
                  ضمن المعدل
                </div>
              </article>
              <article className="metric-card" data-testid="metric-members">
                <span className="metric-label">أعضاء تحت الإدارة</span>
                <div className="metric-value">1,284</div>
                <div className="metric-foot">آخر مزامنة منذ 3 دقائق</div>
              </article>
            </div>
          </section>

          <section className="content-grid animate-in delay-3">
            <article className="panel" aria-labelledby="identity-title">
              <div className="panel-title">
                <h3 id="identity-title">هوية البوت</h3>
                <span>IDENTITY / 02</span>
              </div>
              <div className="bot-identity">
                <div className="bot-avatar" aria-hidden="true">MG</div>
                <div>
                  <p className="bot-title">حارس العضوية</p>
                  <div className="bot-handle" data-testid="text-bot-handle">
                    @membership_guard_bot
                  </div>
                </div>
                <button
                  className="text-button"
                  type="button"
                  onClick={copyHandle}
                  data-testid="button-copy-bot-handle"
                  aria-label="نسخ اسم مستخدم البوت"
                >
                  {isCopied ? <Check size={14} /> : <Copy size={14} />}
                  {isCopied ? 'تم النسخ' : 'نسخ'}
                </button>
              </div>
              <div className="details">
                <div className="detail">
                  <span className="detail-label">إصدار البوت</span>
                  <span className="detail-value">v2.4.1</span>
                </div>
                <div className="detail">
                  <span className="detail-label">بيئة التشغيل</span>
                  <span className="detail-value">production</span>
                </div>
                <div className="detail">
                  <span className="detail-label">حالة قاعدة البيانات</span>
                  <span className="detail-value">متصلة</span>
                </div>
              </div>
            </article>

            <article className="panel" aria-labelledby="events-title">
              <div className="panel-title">
                <h3 id="events-title">سجل المراقبة</h3>
                <span>LIVE FEED</span>
              </div>
              <div className="timeline">
                <div className="timeline-item">
                  <span className="timeline-marker" aria-hidden="true" />
                  <span className="timeline-event">اتصال تيليجرام مستقر</span>
                  <span className="timeline-time">منذ 1 د</span>
                </div>
                <div className="timeline-item">
                  <span className="timeline-marker" aria-hidden="true" />
                  <span className="timeline-event">اكتملت مزامنة العضويات</span>
                  <span className="timeline-time">منذ 3 د</span>
                </div>
                <div className="timeline-item">
                  <span className="timeline-marker" aria-hidden="true" />
                  <span className="timeline-event">فحص الصحة الدوري</span>
                  <span className="timeline-time">منذ 5 د</span>
                </div>
              </div>
            </article>
          </section>

          <section
            className="deployment animate-in delay-4"
            id="deployment-guide"
            aria-labelledby="deployment-title"
          >
            <div className="deployment-icon" aria-hidden="true">
              <CloudCog size={23} strokeWidth={1.7} />
            </div>
            <div>
              <h3 id="deployment-title">لم يتم نشر الخدمة بعد؟</h3>
              <p>
                إذا كانت هذه أول مرة لك، ابدأ بربط رمز البوت، ثم اختر مجموعة
                التشغيل. بعد النشر سيظهر الفحص الأول هنا تلقائياً.
              </p>
              <div className="deploy-steps" aria-label="خطوات النشر">
                <span>ربط البوت</span>
                <i aria-hidden="true" />
                <span>اختيار المجموعة</span>
                <i aria-hidden="true" />
                <span>بدء المراقبة</span>
              </div>
            </div>
            <button
              className="refresh-button"
              type="button"
              onClick={scrollToDeployment}
              data-testid="button-deployment-guide"
            >
              <ShieldCheck size={14} strokeWidth={1.8} />
              دليل البداية
            </button>
          </section>
        </main>

        <footer className="footer animate-in delay-4">
          <span>يتم الفحص كل 60 ثانية</span>
          <span>حالة النظام: مستقرة</span>
        </footer>
      </div>
    </div>
  );
}

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
