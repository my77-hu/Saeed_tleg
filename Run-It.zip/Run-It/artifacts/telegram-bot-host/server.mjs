import { spawn } from "node:child_process";
import { createReadStream, existsSync, statSync } from "node:fs";
import { createServer } from "node:http";
import { extname, join, normalize, resolve } from "node:path";

const artifactRoot = resolve(import.meta.dirname);
const projectRoot = resolve(artifactRoot, "../..");
const publicRoot = resolve(artifactRoot, "dist/public");
const botScript = resolve(projectRoot, "bot.py");
const port = Number(process.env.PORT || 19870);

let botProcess = null;
let shuttingDown = false;
let restartTimer = null;
let startedAt = Date.now();

const contentTypes = {
  ".css": "text/css; charset=utf-8",
  ".gif": "image/gif",
  ".html": "text/html; charset=utf-8",
  ".ico": "image/x-icon",
  ".jpg": "image/jpeg",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".svg": "image/svg+xml",
  ".webp": "image/webp",
};

function launchBot() {
  if (shuttingDown) return;

  console.log("Starting Telegram bot process...");
  botProcess = spawn("python3", [botScript], {
    cwd: projectRoot,
    env: process.env,
    stdio: "inherit",
  });

  botProcess.on("error", (error) => {
    console.error("Unable to start bot process:", error);
  });

  botProcess.on("exit", (code, signal) => {
    botProcess = null;
    if (shuttingDown) return;

    console.error(
      `Bot process stopped (code=${code ?? "null"}, signal=${signal ?? "none"}). Restarting in 5 seconds...`,
    );
    restartTimer = setTimeout(launchBot, 5000);
  });
}

function sendJson(response, statusCode, body) {
  response.writeHead(statusCode, {
    "content-type": "application/json; charset=utf-8",
    "cache-control": "no-store",
  });
  response.end(JSON.stringify(body));
}

function serveStatic(request, response) {
  const requestPath = decodeURIComponent((request.url || "/").split("?")[0]);
  const relativePath = requestPath === "/" ? "index.html" : requestPath.slice(1);
  const candidate = resolve(publicRoot, normalize(relativePath));

  if (!candidate.startsWith(`${publicRoot}/`) || !existsSync(candidate)) {
    const fallback = join(publicRoot, "index.html");
    if (!existsSync(fallback)) {
      sendJson(response, 503, { status: "starting" });
      return;
    }
    response.writeHead(200, { "content-type": "text/html; charset=utf-8" });
    createReadStream(fallback).pipe(response);
    return;
  }

  if (!statSync(candidate).isFile()) {
    sendJson(response, 404, { error: "Not found" });
    return;
  }

  response.writeHead(200, {
    "content-type":
      contentTypes[extname(candidate)] || "application/octet-stream",
    "cache-control":
      candidate.endsWith("index.html")
        ? "no-store"
        : "public, max-age=31536000, immutable",
  });
  createReadStream(candidate).pipe(response);
}

const server = createServer((request, response) => {
  const requestPath = (request.url || "/").split("?")[0];

  if (requestPath === "/healthz") {
    sendJson(response, 200, {
      status: botProcess ? "running" : "restarting",
      botPid: botProcess?.pid ?? null,
      uptimeSeconds: Math.floor((Date.now() - startedAt) / 1000),
    });
    return;
  }

  serveStatic(request, response);
});

server.listen(port, "0.0.0.0", () => {
  console.log(`Telegram Bot Host listening on port ${port}`);
  launchBot();
});

function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  if (restartTimer) clearTimeout(restartTimer);
  console.log(`Received ${signal}; stopping bot host...`);
  botProcess?.kill("SIGTERM");
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 10000).unref();
}

process.on("SIGINT", () => shutdown("SIGINT"));
process.on("SIGTERM", () => shutdown("SIGTERM"));