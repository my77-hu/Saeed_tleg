---
name: Telegram adder bot invite counting
description: Why "successful" InviteToChannelRequest calls can still not add the member, and why non-local phone numbers behave less reliably in mass-add bots.
---

In `bot.py` (Telethon-based mass-add bot), `InviteToChannelRequest` can return without raising
an exception even when the invited user never actually becomes a group member — e.g. the
target group has "approve new members" enabled (pending join request) or the invite is
silently dropped by Telegram's anti-spam heuristics. Counting on the absence of an exception
as a successful add caused the daily per-account limit counter to fill up (accounts hit their
40/day cap) while far fewer real members actually joined the group.

**Why:** Telegram's invite APIs don't reliably raise `UserPrivacyRestrictedError` in all cases
where the invite doesn't result in real membership — some paths fail silently.

**How to apply:** After calling `InviteToChannelRequest`, verify the user actually became a
participant (e.g. `GetParticipantRequest` catching `UserNotParticipantError`) before
incrementing the daily-added counter. If verification itself errors out for unrelated reasons
(permissions, etc.), assume success rather than dropping a real add.

Also relevant: this bot uses the public/shared Telegram Desktop API credentials
(`api_id=2040`), which are heavily used worldwide and more aggressively flagged by Telegram's
anti-spam system. This can make invite behavior less stable for accounts/phone numbers that
don't already have an established trust history (e.g. non-local numbers), independent of any
app-level bug. A dedicated `api_id`/`api_hash` from my.telegram.org per project reduces (but
does not eliminate) this instability.
