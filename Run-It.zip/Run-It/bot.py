import asyncio
import logging
import sqlite3
import os
import re
from datetime import datetime
from telethon import TelegramClient, types, functions
from telethon.errors import (
    FloodWaitError, UserAlreadyParticipantError, PeerFloodError,
    ChannelPrivateError, UserBannedInChannelError, UserPrivacyRestrictedError,
    UserNotParticipantError
)
from telethon.tl.functions.channels import GetParticipantRequest
from aiogram import Bot, Dispatcher, F
from aiogram import types as aio_types
from aiogram.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage

# ================== CONFIG ==================
API_ID = 2040
API_HASH = "b18441a1ff607e10a989891a5462e627"
BOT_TOKEN = "8832938514:AAGaGEcazDlQ4ewtkMZZyzl7zvjv_3pu6AU"

SOURCE_GROUP = None
TARGET_GROUP = None
SCRAPER_PHONE = None

usernames_list = []

# ================== DATABASE ==================
os.makedirs("sessions", exist_ok=True)
conn = sqlite3.connect('adder.db', check_same_thread=False)
c = conn.cursor()
c.execute('''CREATE TABLE IF NOT EXISTS sessions (phone TEXT PRIMARY KEY, session_name TEXT, is_active INTEGER DEFAULT 1)''')
c.execute('''CREATE TABLE IF NOT EXISTS stats (date TEXT, phone TEXT, added INTEGER, PRIMARY KEY(date, phone))''')
conn.commit()

# ================== BOT SETUP ==================
bot = Bot(token=BOT_TOKEN)
storage = MemoryStorage()
dp = Dispatcher(storage=storage)

clients = {}

class BotStates(StatesGroup):
    waiting_phone = State()
    waiting_code = State()
    waiting_source = State()
    waiting_target = State()

def main_menu():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="➕ إضافة حساب", callback_data="add_account")],
        [InlineKeyboardButton(text="📋 قائمة الحسابات", callback_data="list_accounts")],
        [InlineKeyboardButton(text="🔎 فحص الحسابات", callback_data="check_accounts")],
        [InlineKeyboardButton(text="🔍 تعيين مجموعة المصدر", callback_data="set_source")],
        [InlineKeyboardButton(text="🎯 تعيين مجموعة الهدف", callback_data="set_target")],
        [InlineKeyboardButton(text="📥 سحب يوزرنيمات من الرسائل", callback_data="scrape_messages")],
        [InlineKeyboardButton(text="▶️ بدء الإضافة", callback_data="start_adding")],
    ])

@dp.message(Command("start"))
async def start(msg: aio_types.Message):
    await msg.answer(
        "🤖 **بوت سحب وإضافة أعضاء تليجرام**\n"
        "• سحب اليوزرنيمات من الرسائل في المجموعة المصدر\n"
        "• حساب واحد فقط يقوم بالسحب (الغير محظور)\n"
        "• باقي الحسابات تضيف بالتوازي",
        reply_markup=main_menu()
    )

# ================== إضافة حساب ==================
@dp.callback_query(F.data == "add_account")
async def add_account(callback: aio_types.CallbackQuery, state: FSMContext):
    await callback.message.answer("📲 أرسل رقم الهاتف مع رمز الدولة:\nمثال: +9647712345678")
    await state.set_state(BotStates.waiting_phone)

@dp.message(BotStates.waiting_phone)
async def process_phone(msg: aio_types.Message, state: FSMContext):
    phone = msg.text.strip()
    await state.update_data(phone=phone)
    client = TelegramClient(f"sessions/{phone}", API_ID, API_HASH)
    await client.connect()
    await client.send_code_request(phone)
    clients[phone] = client
    await msg.answer("🔢 أرسل الكود الذي وصلك:")
    await state.update_data(phone=phone)
    await state.set_state(BotStates.waiting_code)

@dp.message(BotStates.waiting_code)
async def process_code(msg: aio_types.Message, state: FSMContext):
    data = await state.get_data()
    phone = data['phone']
    try:
        client = clients.get(phone)
        if not client:
            await msg.answer("❌ انتهت الجلسة، أعد إضافة الحساب")
            await state.clear()
            return
        await client.sign_in(phone, msg.text.strip())
        c.execute("INSERT OR REPLACE INTO sessions (phone, session_name) VALUES (?, ?)",
                 (phone, f"sessions/{phone}"))
        conn.commit()
        await msg.answer("✅ تم تسجيل الحساب بنجاح!", reply_markup=main_menu())
    except Exception as e:
        await msg.answer(f"❌ خطأ: {str(e)}")
    await state.clear()

# ================== قائمة الحسابات ==================
@dp.callback_query(F.data == "list_accounts")
async def list_accounts(callback: aio_types.CallbackQuery):
    c.execute("SELECT phone, is_active FROM sessions")
    rows = c.fetchall()
    if not rows:
        await callback.message.answer("📋 لا توجد حسابات مسجلة بعد.")
        return
    text = "📋 **الحسابات المسجلة:**\n"
    for phone, is_active in rows:
        status = "✅ نشط" if is_active else "❌ معطّل"
        text += f"• `{phone}` — {status}\n"
    await callback.message.answer(text, reply_markup=main_menu())

# ================== فحص الحسابات ==================
@dp.callback_query(F.data == "check_accounts")
async def check_accounts(callback: aio_types.CallbackQuery):
    c.execute("SELECT phone FROM sessions WHERE is_active=1")
    accounts = [row[0] for row in c.fetchall()]
    if not accounts:
        await callback.message.answer("📋 لا توجد حسابات مسجلة.")
        return

    await callback.message.answer(f"🔎 جاري فحص {len(accounts)} حساب...")

    ok = []
    bad = []
    for phone in accounts:
        try:
            client = TelegramClient(f"sessions/{phone}", API_ID, API_HASH)
            await client.connect()
            if await client.is_user_authorized():
                me = await client.get_me()
                ok.append(f"✅ {phone} — @{me.username or me.first_name}")
                clients[phone] = client
            else:
                bad.append(f"❌ {phone} — session منتهية (يحتاج إعادة تسجيل)")
                c.execute("UPDATE sessions SET is_active=0 WHERE phone=?", (phone,))
                conn.commit()
                await client.disconnect()
        except Exception as e:
            bad.append(f"⚠️ {phone} — {str(e)[:80]}")

    lines = ["🔎 **نتيجة الفحص:**\n"]
    if ok:
        lines.append("**تعمل بشكل صحيح:**")
        lines += ok
    if bad:
        lines.append("\n**مشاكل (تم تعطيلها):**")
        lines += bad

    await callback.message.answer("\n".join(lines), reply_markup=main_menu())

# ================== تعيين المجموعات ==================
@dp.callback_query(F.data == "set_source")
async def set_source(callback: aio_types.CallbackQuery, state: FSMContext):
    await callback.message.answer("🔍 أرسل معرف المجموعة المصدر (مثال: @groupname أو رابط)")
    await state.set_state(BotStates.waiting_source)

@dp.message(BotStates.waiting_source)
async def save_source(msg: aio_types.Message, state: FSMContext):
    global SOURCE_GROUP
    SOURCE_GROUP = msg.text.strip()
    await msg.answer(f"✅ تم تعيين مجموعة المصدر: {SOURCE_GROUP}", reply_markup=main_menu())
    await state.clear()

@dp.callback_query(F.data == "set_target")
async def set_target(callback: aio_types.CallbackQuery, state: FSMContext):
    await callback.message.answer("🎯 أرسل معرف مجموعة الهدف")
    await state.set_state(BotStates.waiting_target)

@dp.message(BotStates.waiting_target)
async def save_target(msg: aio_types.Message, state: FSMContext):
    global TARGET_GROUP
    TARGET_GROUP = msg.text.strip()
    await msg.answer(f"✅ تم تعيين مجموعة الهدف: {TARGET_GROUP}", reply_markup=main_menu())
    await state.clear()

# ================== سحب الأعضاء ==================
@dp.callback_query(F.data == "scrape_messages")
async def scrape_from_messages(callback: aio_types.CallbackQuery):
    if not SOURCE_GROUP:
        await callback.message.answer("❌ لم يتم تعيين مجموعة المصدر بعد!")
        return

    await callback.message.answer("🔍 جاري البحث عن حساب غير محظور للسحب...")

    c.execute("SELECT phone FROM sessions WHERE is_active=1")
    accounts = [row[0] for row in c.fetchall()]

    global usernames_list
    usernames_list = []
    scraper_found = False

    for phone in accounts:
        try:
            client = await get_client(phone)
            group_entity = await client.get_entity(SOURCE_GROUP)

            # اختبار الوصول بسحب عضو واحد
            test = await client.get_participants(group_entity, limit=1)
            if not test:
                continue

            await callback.message.answer(
                f"✅ الحساب {phone} يعمل → جاري سحب الأعضاء...\n"
                f"⏳ قد يستغرق بضع ثوانٍ حسب حجم المجموعة"
            )

            seen = set()
            msg_count = 0

            await callback.message.answer("📥 جاري قراءة الرسائل لسحب أصحاب اليوزرنيمات...")

            # ── السحب من الرسائل فقط (مناسب للمجموعات ذات الأعضاء المخفيين) ──
            async for message in client.iter_messages(group_entity, limit=None):
                msg_count += 1

                # سحب من sender مباشرة إن كان متاحاً
                if message.sender and hasattr(message.sender, 'username'):
                    sender = message.sender
                    if sender.username and not getattr(sender, 'bot', False):
                        uname = sender.username.lower()
                        if uname not in seen:
                            seen.add(uname)
                            usernames_list.append(sender.username)

                # سحب @mentions من نص الرسالة
                if message.entities and message.message:
                    for ent in message.entities:
                        if isinstance(ent, types.MessageEntityMention):
                            username = message.message[ent.offset:ent.offset + ent.length].lstrip('@')
                            if username and username.lower() not in seen:
                                seen.add(username.lower())
                                usernames_list.append(username)

                # تقرير كل 500 رسالة
                if msg_count % 500 == 0:
                    await callback.message.answer(
                        f"📊 قُرئ {msg_count} رسالة | وُجد {len(usernames_list)} عضو"
                    )

                if len(usernames_list) >= 1000:
                    break

            scraper_found = True
            break

        except (ChannelPrivateError, UserBannedInChannelError):
            await callback.message.answer(f"⚠️ الحساب {phone} محظور في المجموعة، جاري تجربة التالي...")
            continue
        except FloodWaitError as e:
            await callback.message.answer(f"⏳ انتظار {e.seconds}ث بسبب flood...")
            await asyncio.sleep(e.seconds)
            continue
        except Exception as e:
            await callback.message.answer(f"⚠️ خطأ في {phone}: {str(e)[:100]}")
            continue

    if scraper_found:
        await callback.message.answer(
            f"✅ تم سحب **{len(usernames_list)}** عضو بنجاح\n"
            f"يمكنك الآن بدء الإضافة ▶️",
            reply_markup=main_menu()
        )
    else:
        await callback.message.answer("❌ لم يتم العثور على حساب غير محظور في المجموعة المصدر")

async def get_client(phone):
    if phone not in clients:
        client = TelegramClient(f"sessions/{phone}", API_ID, API_HASH)
        await client.connect()
        if not await client.is_user_authorized():
            raise Exception(f"الحساب {phone} غير مصرّح — يجب إعادة تسجيل الدخول")
        clients[phone] = client
    else:
        # تحقق من الاتصال وأعد الاتصال إن انقطع
        if not clients[phone].is_connected():
            await clients[phone].connect()
    return clients[phone]

def increment_added(phone):
    today = datetime.now().strftime("%Y-%m-%d")
    c.execute("""INSERT INTO stats (date, phone, added) VALUES (?, ?, 1)
                 ON CONFLICT(date, phone) DO UPDATE SET added = added + 1""", (today, phone))
    conn.commit()

# ================== بدء الإضافة ==================
DAILY_LIMIT = 40  # الحد اليومي الآمن لكل حساب

def get_today_added(phone):
    today = datetime.now().strftime("%Y-%m-%d")
    c.execute("SELECT added FROM stats WHERE date=? AND phone=?", (today, phone))
    row = c.fetchone()
    return row[0] if row else 0

@dp.callback_query(F.data == "start_adding")
async def start_adding(callback: aio_types.CallbackQuery):
    if not TARGET_GROUP or not usernames_list:
        await callback.message.answer("❌ يجب سحب اليوزرنيمات وتعيين الهدف أولاً")
        return

    c.execute("SELECT phone FROM sessions WHERE is_active=1")
    all_accounts = [row[0] for row in c.fetchall() if row[0] != SCRAPER_PHONE]

    # فلتر: تحقق من التصريح + الحد اليومي
    adders = []
    for phone in all_accounts:
        # تحقق من أن الـ session مصرّحة
        try:
            client = TelegramClient(f"sessions/{phone}", API_ID, API_HASH)
            await client.connect()
            if not await client.is_user_authorized():
                await callback.message.answer(f"❌ {phone} — session منتهية، سيُتخطى (أعد تسجيل الدخول)")
                c.execute("UPDATE sessions SET is_active=0 WHERE phone=?", (phone,))
                conn.commit()
                continue
            clients[phone] = client
        except Exception as e:
            await callback.message.answer(f"⚠️ {phone} — خطأ اتصال: {str(e)[:60]}")
            continue

        today_count = get_today_added(phone)
        remaining = DAILY_LIMIT - today_count
        if remaining > 0:
            adders.append((phone, remaining))
        else:
            await callback.message.answer(f"⚠️ {phone} — وصل حده اليومي ({DAILY_LIMIT}), سيُتخطى")

    if not adders:
        await callback.message.answer(
            "❌ كل الحسابات وصلت حدها اليومي!\n"
            f"الحد اليومي الآمن: {DAILY_LIMIT} إضافة/حساب\n"
            "حاول مجدداً غداً.",
            reply_markup=main_menu()
        )
        return

    total_capacity = sum(r for _, r in adders)
    await callback.message.answer(
        f"🚀 بدء الإضافة بالتوازي:\n"
        + "\n".join([f"  • {p} — متبقي له {r} إضافة اليوم" for p, r in adders])
        + f"\n\nإجمالي قدرة اليوم: {total_capacity} عضو"
    )

    chat_id = callback.message.chat.id

    # تقسيم القائمة بالتساوي بين الحسابات النشطة
    n = len(adders)
    chunks = [usernames_list[i::n] for i in range(n)]

    tasks = [
        add_users_task(phone, chunk, TARGET_GROUP, remaining, chat_id)
        for (phone, remaining), chunk in zip(adders, chunks)
    ]
    await asyncio.gather(*tasks, return_exceptions=True)

    # تقرير نهائي
    summary = []
    for phone, _ in adders:
        today_count = get_today_added(phone)
        summary.append(f"  • {phone}: أضاف {today_count} عضو اليوم")

    await bot.send_message(
        chat_id,
        "✅ انتهت عملية الإضافة!\n\n📊 ملخص:\n" + "\n".join(summary),
        reply_markup=main_menu()
    )

async def add_users_task(phone, usernames, target, daily_remaining, chat_id):
    client = await get_client(phone)
    count = 0
    skipped = 0

    # جلب الـ target مرة واحدة فقط خارج الحلقة
    try:
        target_entity = await client.get_entity(target)
    except Exception as e:
        await bot.send_message(chat_id, f"❌ {phone}: تعذّر الوصول للمجموعة الهدف — {str(e)[:80]}")
        return

    for username in usernames:
        if count >= daily_remaining:
            await bot.send_message(chat_id, f"🛑 {phone}: وصل حده اليومي ({daily_remaining} إضافة)")
            break
        try:
            user = await client.get_entity(username)
            await client(functions.channels.InviteToChannelRequest(
                channel=target_entity,
                users=[user]
            ))

            # تحقق فعلي من انضمام العضو قبل احتسابه — بعض الدعوات
            # تُقبل من تيليجرام بدون خطأ لكن العضو لا ينضم فعلياً
            # (خصوصية، طلب انضمام معلّق، إلخ) فتُحسب زوراً كإضافة ناجحة.
            joined = False
            try:
                await client(GetParticipantRequest(channel=target_entity, participant=user))
                joined = True
            except UserNotParticipantError:
                joined = False
            except Exception:
                # تعذّر التحقق لسبب آخر (صلاحيات مثلاً) — نفترض النجاح
                # حتى لا نُسقط إضافات صحيحة بسبب فشل التحقق نفسه
                joined = True

            if joined:
                count += 1
                increment_added(phone)

                # تقرير كل 10 إضافات
                if count % 10 == 0:
                    await bot.send_message(chat_id, f"📲 {phone}: أضاف {count} عضو حتى الآن...")
            else:
                skipped += 1
                await bot.send_message(
                    chat_id,
                    f"⚠️ {phone}: الدعوة لـ @{username} لم تُقبل فعلياً (خصوصية/طلب انضمام معلّق) — لم تُحتسب"
                )

            await asyncio.sleep(6)  # تأخير آمن بين الإضافات

        except FloodWaitError as e:
            await bot.send_message(chat_id, f"⏳ {phone}: FloodWait — انتظار {e.seconds}ث ثم يكمل...")
            await asyncio.sleep(e.seconds + 5)

        except UserAlreadyParticipantError:
            skipped += 1
            await asyncio.sleep(2)

        except UserPrivacyRestrictedError:
            skipped += 1
            await asyncio.sleep(2)

        except (UserBannedInChannelError, PeerFloodError) as e:
            await bot.send_message(chat_id, f"🚫 {phone}: محظور من الإضافة — {type(e).__name__}")
            break

        except Exception as e:
            err = str(e)[:100]
            await bot.send_message(chat_id, f"⚠️ {phone} → خطأ عند إضافة @{username}: {err}")
            skipped += 1
            await asyncio.sleep(3)

    await bot.send_message(
        chat_id,
        f"✔️ {phone} انتهى: أضاف {count} | تخطّى {skipped}"
    )

# ================== RUN ==================
async def main():
    os.makedirs("sessions", exist_ok=True)
    logging.basicConfig(level=logging.INFO)
    print("✅ البوت يعمل - السحب من الرسائل + تجنب الحظر")
    retry_delay = 5

    # إبقاء البوت مستمراً وإعادة الاتصال تلقائياً عند انقطاع الشبكة
    # أو حدوث خطأ مؤقت من Telegram.
    while True:
        try:
            await dp.start_polling(bot)
            print(f"⚠️ توقف الاتصال، ستتم إعادة المحاولة بعد {retry_delay} ثوانٍ...")
        except (asyncio.CancelledError, KeyboardInterrupt):
            raise
        except Exception:
            logging.exception(
                "انقطع اتصال البوت، ستتم إعادة المحاولة بعد %s ثوانٍ",
                retry_delay,
            )

        await asyncio.sleep(retry_delay)

if __name__ == "__main__":
    asyncio.run(main())
